<?php
/**
 * Plugin Name:       Yoodule Stripe
 * Plugin URI:        http://localhost/kn0wn_an0nym0us/wp-admin/plugin-editor.php
 * Description:       Run Yoodule Stripe API.
 * Version:           1.0.0
 * Author:            Oluwagbemi Emmanuel Oluwafemi
 * Author URI:        http://localhost/kn0wn_an0nym0us/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        http://localhost/kn0wn_an0nym0us/wp-admin/plugin-editor.php
 * Text Domain:       yoodule-stripe-plugin
 * Domain Path:       /languages
 */
 
 function yoodulestripe_func() {
  