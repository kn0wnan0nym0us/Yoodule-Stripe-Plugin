<?php
/**
 * @author Oluwagbemi Emmanuel Oluwafemi
 * @version 1.14
 *
 *
 * Plugin Name: Yoodule Stripe Datatable
 * Plugin URI: http://localhost/kn0wn_an0nym0us/wp-admin/plugin-editor.php
 * Version: 1.14
 * Requires at least: 5.6
 * Requires PHP: 5.6.20
 * Author: Oluwagbemi Emmanuel Oluwafemi
 * Author URI: http://localhost/kn0wnan0nym0us/
 * License: GPL 2
 */

// Prohibit direct script loading.
defined( 'ABSPATH' ) || die( 'No direct script access allowed!' );

// Define certain plugin variables as constants.
if ( ! defined( 'TABLEPRESS_ABSPATH' ) ) {
	define( 'TABLEPRESS_ABSPATH', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'TABLEPRESS__FILE__' ) ) {
	define( 'TABLEPRESS__FILE__', __FILE__ );
}

if ( ! defined( 'TABLEPRESS__DIR__' ) ) {
	define( 'TABLEPRESS__DIR__', __DIR__ );
}

if ( ! defined( 'TABLEPRESS_BASENAME' ) ) {
	define( 'TABLEPRESS_BASENAME', plugin_basename( TABLEPRESS__FILE__ ) );
}

/*
 * Define global JSON encoding options that TablePress uses.
 */
if ( ! defined( 'TABLEPRESS_JSON_OPTIONS' ) ) {
	$tablepress_json_options = 0;
	$tablepress_json_options |= JSON_UNESCAPED_SLASHES; // Don't escape slashes to make search/replace of URLs in the database much easier.
	define( 'TABLEPRESS_JSON_OPTIONS', $tablepress_json_options );
	unset( $tablepress_json_options );
}

/**
 * Load TablePress class, which holds common functions and variables.
 */
require_once TABLEPRESS_ABSPATH . 'classes/class-tablepress.php';

// Start up TablePress on WordPress's "init" action hook.
add_action( 'init', array( 'TablePress', 'run' ) );
